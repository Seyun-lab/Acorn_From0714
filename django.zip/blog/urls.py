from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('posts/', views.posts_view, name='posts'),
    path('post/<int:pk>/', views.post_detail_view, name='post_detail'),
    path('post/create/', views.post_create_view, name='post_create'),
    path('post/<int:pk>/edit/', views.post_edit_view, name='post_edit'),
]
