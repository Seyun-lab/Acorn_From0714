from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Post
from .forms import PostForm

# Create your views here.

def index(request):
    return render(request, 'blog/index.html')

def login_view(request):
    return render(request, 'registration/login.html')

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'계정이 생성되었습니다: {username}!')
            login(request, user)
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

def posts_view(request):
    posts = Post.objects.all().order_by('-created_at')
    return render(request, 'blog/posts.html', {'posts': posts})

@login_required
def post_create_view(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect('post_detail', pk=post.pk)
    else:
        form = PostForm()
    return render(request, 'blog/post_create.html', {'form': form})

def post_detail_view(request, pk):
    post = get_object_or_404(Post, pk=pk)
    
    # 삭제 요청 처리
    if request.method == 'POST' and request.POST.get('delete'):
        if post.author == request.user:
            post.delete()
            messages.success(request, '게시글이 삭제되었습니다.')
            return redirect('posts')
        else:
            messages.error(request, '본인의 게시글만 삭제할 수 있습니다.')
    
    return render(request, 'blog/post_detail.html', {'post': post})

@login_required
def post_edit_view(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if post.author != request.user:
        messages.error(request, '본인의 게시글만 수정할 수 있습니다.')
        return redirect('post_detail', pk=pk)
    
    if request.method == 'POST':
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect('post_detail', pk=pk)
    else:
        form = PostForm(instance=post)
    return render(request, 'blog/post_edit.html', {'form': form, 'post': post})
